//
//  Usuario_Valido.swift
//  Metro_1
//
//  Created by iOS Lab on 29/04/23.
//

import SwiftUI

struct Usuario_Valido: View {
    var body: some View {
        Text("Hola Master, bienvenido").font(.title).foregroundColor(.blue)
    }
}

struct Usuario_Valido_Previews: PreviewProvider {
    static var previews: some View {
        Usuario_Valido()
    }
}
