//
//  Metro_1App.swift
//  Metro_1
//
//  Created by iOS Lab on 29/04/23.
//

import SwiftUI

@main
struct Metro_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
