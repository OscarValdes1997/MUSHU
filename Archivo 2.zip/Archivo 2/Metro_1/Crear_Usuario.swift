//
//  Crear_Usuario.swift
//  Metro_1
//
//  Created by iOS Lab on 29/04/23.
//

import SwiftUI

struct Crear_Usuario: View {
    var body: some View {
        Text("Dame tus datos Master")
    }
}

struct Crear_Usuario_Previews: PreviewProvider {
    static var previews: some View {
        Crear_Usuario()
    }
}
