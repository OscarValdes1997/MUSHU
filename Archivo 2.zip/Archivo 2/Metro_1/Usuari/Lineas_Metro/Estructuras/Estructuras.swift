//
//  Estructuras.swift
//  Metro_1
//
//  Created by iOS Lab on 29/04/23.
//

import Foundation
import SwiftUI

struct Metro{
    var id: Int
    var avatar: Image
    var titulo: String
    var description: String
    var imagenes1: Image
}
