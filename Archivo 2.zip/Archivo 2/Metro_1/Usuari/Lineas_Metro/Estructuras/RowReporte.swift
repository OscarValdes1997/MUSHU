//
//  RowReporte.swift
//  Metro_1
//
//  Created by iOS Lab on 30/04/23.
//

import SwiftUI

struct RowReporte: View {
    var body: some View {
        ScrollView{
            ZStack{
                VStack{
                    VStack{
                        
                        Spacer()
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            
                            Text("En el Zocalo hay concierto")
                            Divider()
                        }
                        
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            Text("En el Zocalo hay concierto")
                            
                            Divider()
                        }
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            
                            Text("En el Zocalo hay concierto")
                            Divider()
                        }
                        
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            Text("En el Zocalo hay concierto")
                            
                            Divider()
                        }
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            
                            Text("En el Zocalo hay concierto")
                            Divider()
                        }
                        
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            Text("En el Zocalo hay concierto")
                            
                            Divider()
                        }
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            
                            Text("En el Zocalo hay concierto")
                            Divider()
                        }
                        
                        HStack{
                            VStack{
                                Image("zocalo").resizable().frame(width: 45, height: 45)
                                Text("30 de abril del 2023")
                                
                            }
                            Text("En el Zocalo hay concierto")
                            
                            Divider()
                        }
                        
                        
                    }
                    
                    HStack{
                        VStack{
                            Image("zocalo").resizable().frame(width: 45, height: 45)
                            Text("30 de abril del 2023")
                            
                        }
                        
                        Text("En el Zocalo hay concierto")
                        Divider()
                    }
                    
                    HStack{
                        VStack{
                            Image("zocalo").resizable().frame(width: 45, height: 45)
                            Text("30 de abril del 2023")
                            
                        }
                        Text("En el Zocalo hay concierto")
                        
                        Divider()
                    }
                    HStack{
                        VStack{
                            Image("zocalo").resizable().frame(width: 45, height: 45)
                            Text("30 de abril del 2023")
                            
                        }
                        
                        Text("En el Zocalo hay concierto")
                        Divider()
                    }
                    
                    HStack{
                        VStack{
                            Image("zocalo").resizable().frame(width: 45, height: 45)
                            Text("30 de abril del 2023")
                            
                        }
                        Text("En el Zocalo hay concierto")
                        
                        Divider()
                    }
                    }//LLave final
                    
                }.foregroundColor(.black)
                
        }

    }
}

struct RowReporte_Previews: PreviewProvider {
    static var previews: some View {
        RowReporte()
    }
}
