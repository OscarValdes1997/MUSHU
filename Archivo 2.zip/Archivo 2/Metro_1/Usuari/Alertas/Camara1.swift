//
//  Camara1.swift
//  Metro_1
//
//  Created by iOS Lab on 30/04/23.
//

import SwiftUI

struct Camara1: View {
        var body: some View {
       
            Text("Hola")
        }
    }

struct Camara1_Previews: PreviewProvider {
    static var previews: some View {
        Camara1()
    }
}
